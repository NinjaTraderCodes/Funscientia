# Funscientia online saves (backend)

<!-- Djihane: write this file in your own words. Keep the headings; replace the notes in <...>. -->

Code-based online saves for Funscientia: the game creates a save and shows the player a code
(e.g. `K7QM-4FXA`); the player can continue on any device by typing it. No accounts, no emails.

## Files

| File | What it does |
| --- | --- |
| `schema.sql` | Creates the `saves` table |
| `functions.sql` | `create_save`, `save_progress`, `load_progress` |
| `security.sql` | Locks the table; opens only the three functions to the game |
| `stats.sql` | (optional) Totals for the team, run in the SQL Editor only |
| `test.html` | Test page: by-hand calls and "Run all checks" |
| `screenshots/` | Proof of the tests |

## Install (in a Supabase project)

Run in the SQL Editor, in this order: `schema.sql`, `functions.sql`, `security.sql`.

## Test

Open `test.html`, paste the project URL and the publishable key, click **Run all checks**.
<Result on my project: 14 / 14 passed, see screenshots/checks.png>

## Security in short

<In your words: why the table cannot be read or changed from the internet, and what the game can do.>

## Changes from the guide

<None. / What you changed, and why.>

## Questions / ideas

<Anything you are unsure about, or would improve.>
