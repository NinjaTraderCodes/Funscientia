Funscientia — Mouth Hammer Mission

كود اللعبة الأصلي مع الصور المستخدمة.

index.html: يحتوي على كود HTML وCSS وJavaScript كاملاً.
assets/: الصور المستخدمة في اللعبة. حافظي على المجلد بجانب index.html.

لفتح اللعبة على الحاسوب: فكّي الضغط ثم افتحي index.html في المتصفح.
لتعديل الكود: افتحي index.html بمحرر نصوص مثل Visual Studio Code.

Original game source, including artwork. No build or installation required.
Extract the ZIP and open index.html in a browser. Keep assets/ beside index.html.
